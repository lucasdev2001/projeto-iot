const { Board, Led } = require("johnny-five");
const board = new Board();

board.on("ready", () => {

    const matrix = new Led.Matrix({
        pins: {
            data: 12,
            clock: 11,
            cs: 10
        }
    });

    matrix.on();

    // type `draw("shape_name")` into the repl to see the shape!
    board.repl.inject({
        matrix,
        draw(shape) {
            matrix.draw(Led.Matrix.CHARS[shape]);
        }
    });
});