const express = require('express');
const bodyParser = require('body-parser');
const { Board, Led, Sensor } = require("johnny-five");
const brightness = require('brightness');
const app = express();
const port = 3000; // caso queira alterar essa porta lembre-se também de alterar a porta usada em "myScript.js"
const board = new Board();

app.use(express.static(__dirname + '/public'));
app.set('view engine', 'ejs');
app.set('views', './views');

var jsonParser = bodyParser.json();

let variavelDeBrilho; //esta é a varíavel que o senhor quer usar, ela é atualizada em tempo real e varia de 1 a 100 :-)

app.get('/', (req, res) => { //página inicial
    res.render('index');
  });

app.post('/form', jsonParser, function (req, res) { //tratamento do 
  res.send(req.body.range); // não retirar do código, sem isso não funciona
  variavelDeBrilho = parseFloat(req.body.range);

});

function iniciarServer() {
    app.listen(port, () => {
        console.log(`Servidor online na porta: ${port}`);
      });
}

board.on("ready",iniciarServer,() => {
    const brightNess = new Sensor({ pin: "A1", threshold: 5 });
    brightNess.on("change", (data) => {
        val = brightNess.fscaleTo(0, 1);
        brightness.set(val);
        console.log("Valor do brilho ", val);
    });
});
