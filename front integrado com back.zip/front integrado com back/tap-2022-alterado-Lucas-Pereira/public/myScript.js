$(document).ready(()=>{
    $('form').on('submit', (e)=>{
        e.preventDefault()
    })
})

$('input').on('input', async (e)=>{

    $('p').text(e.target.value)

    const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json'},
        body: JSON.stringify({"range" : e.target.value})
    }
   fetch('http://localhost:3000/form', requestOptions)
    console.log(e.target.value);
})