const express = require('express')
const bodyParser = require('body-parser')
const app = express()
const port = 3000 //caso queira alterar a porta lembre-se também de altera-la em "myScript.js"

app.use(express.static(__dirname + '/public'));
app.set('view engine', 'ejs')
app.set('views', './views')

var jsonParser = bodyParser.json()

let variavelDeBrilho; //esta é a varíavel que o senhor quer usar, ela é atualizada em tempo real :-)


app.get('/', (req, res) => {
  res.render('index')
})

app.post('/form', jsonParser, function (req, res) {
  res.send(req.body.range) // não retirar do código, sem isso não funciona
  variavelDeBrilho = parseFloat(req.body.range)
  console.log(variavelDeBrilho) //verificar se a variável que esta no servidor esta sendo alterada em tempo real, apos verificiar pode retirar para evitar spam.

})

app.listen(port, () => {
  console.log(`Servidor online na porta: ${port}`)
})